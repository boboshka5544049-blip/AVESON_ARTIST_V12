# AVESON ARTIST v12

GitHub-ready Android Artist app prototype.

## v12 changes
- Fixed Java `self-reference in initializer` build error for playback progress.
- Uses Java 17 compile options.
- Updated GitHub Actions to `actions/setup-java@v5` and Gradle 8.9.
- Artist release upload now copies the selected audio and cover files into the app's private storage instead of saving only filenames/URIs.
- Audio playback uses the stored local audio file when available.
- Added optional `Lyrics / matn` field. It is **не обязательно / optional** and is saved with the release when provided.
- Release details show lyrics when supplied.

## Required release fields
- Release title
- Artist name
- Genre
- Release date (YYYY-MM-DD)
- Audio file
- Cover art

## Optional
- Version / Single
- Lyrics / matn

This is still a local Android prototype. The actual production server-side multipart upload, authentication, PostgreSQL, rights, royalties, and DSP delivery should be connected to the AVESON backend in the next integration step.
